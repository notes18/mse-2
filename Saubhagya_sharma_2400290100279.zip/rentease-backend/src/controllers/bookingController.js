import mongoose from "mongoose";
import Booking from "../models/Booking.js";
import Vehicle from "../models/Vehicle.js";
import asyncHandler from "../utils/asyncHandler.js";

const createBooking = asyncHandler(async (req, res) => {
  const { vehicleId, pickupDate, returnDate } = req.body;

  if (!mongoose.isValidObjectId(vehicleId)) {
    return res.status(400).json({ message: "Invalid vehicleId." });
  }

  const pickup = new Date(pickupDate);
  const dropoff = new Date(returnDate);
  if (Number.isNaN(pickup.getTime()) || Number.isNaN(dropoff.getTime())) {
    return res.status(400).json({ message: "Pickup and return dates must be valid." });
  }
  if (pickup < startOfToday()) {
    return res.status(400).json({ message: "Past pickup dates are not allowed." });
  }
  if (dropoff <= pickup) {
    return res.status(400).json({ message: "Return date must be later than pickup date." });
  }

  const vehicle = await Vehicle.findById(vehicleId);
  if (!vehicle) return res.status(404).json({ message: "Vehicle not found." });
  if (vehicle.availabilityStatus !== "Available") {
    return res.status(409).json({ message: "Vehicle is marked unavailable." });
  }

  const overlapping = await Booking.findOne({
    vehicleId,
    bookingStatus: "Confirmed",
    pickupDate: { $lt: dropoff },
    returnDate: { $gt: pickup }
  });

  if (overlapping) {
    return res.status(409).json({ message: "Vehicle is already booked for an overlapping date range." });
  }

  const numberOfDays = Math.ceil((dropoff - pickup) / (1000 * 60 * 60 * 24));
  const totalAmount = numberOfDays * vehicle.pricePerDay;

  const booking = await Booking.create({
    userId: req.user._id,
    vehicleId,
    pickupDate: pickup,
    returnDate: dropoff,
    numberOfDays,
    totalAmount,
    bookingStatus: "Confirmed"
  });

  res.status(201).json({ message: "Booking created successfully.", booking });
});

function startOfToday() {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return today;
}

const getMyBookings = asyncHandler(async (req, res) => {
  const bookings = await Booking.find({ userId: req.user._id })
    .populate("vehicleId")
    .sort({ bookingDate: -1 });
  res.json({ count: bookings.length, bookings });
});

const getBookingById = asyncHandler(async (req, res) => {
  const booking = await Booking.findById(req.params.id).populate("vehicleId");
  if (!booking) return res.status(404).json({ message: "Booking not found." });

  if (req.user.role !== "Admin" && booking.userId.toString() !== req.user._id.toString()) {
    return res.status(403).json({ message: "You cannot view another customer's booking." });
  }
  res.json({ booking });
});

const cancelBooking = asyncHandler(async (req, res) => {
  const booking = await Booking.findById(req.params.id);
  if (!booking) return res.status(404).json({ message: "Booking not found." });

  if (req.user.role !== "Admin" && booking.userId.toString() !== req.user._id.toString()) {
    return res.status(403).json({ message: "You cannot cancel another customer's booking." });
  }
  if (booking.bookingStatus === "Cancelled") {
    return res.status(400).json({ message: "Booking is already cancelled." });
  }

  booking.bookingStatus = "Cancelled";
  await booking.save();

  res.json({ message: "Booking cancelled. The dates are now available for new bookings.", booking });
});

export { createBooking, getMyBookings, getBookingById, cancelBooking };
