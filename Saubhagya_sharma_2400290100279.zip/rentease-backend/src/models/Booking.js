import mongoose from "mongoose";

const bookingSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  vehicleId: { type: mongoose.Schema.Types.ObjectId, ref: "Vehicle", required: true },
  pickupDate: { type: Date, required: true },
  returnDate: { type: Date, required: true },
  numberOfDays: { type: Number, required: true, min: 1 },
  totalAmount: { type: Number, required: true, min: 0 },
  bookingStatus: { type: String, enum: ["Confirmed", "Cancelled"], default: "Confirmed" },
  bookingDate: { type: Date, default: Date.now }
}, { timestamps: true });

bookingSchema.index({ vehicleId: 1, pickupDate: 1, returnDate: 1, bookingStatus: 1 });

export default mongoose.model("Booking", bookingSchema);
