import "dotenv/config";
import app from "./src/app.js";
import connectDB from "./src/config/db.js";

const PORT = process.env.PORT || 5000;

async function start() {
  await connectDB();
  app.listen(PORT, () => console.log(`RentEase API running on port ${PORT}`));
}

start().catch((error) => {
  console.error("Failed to start server:", error.message);
  process.exit(1);
});
