import Vehicle from "../models/Vehicle.js";
import asyncHandler from "../utils/asyncHandler.js";

const createVehicle = asyncHandler(async (req, res) => {
  const vehicle = await Vehicle.create({ ...req.body, createdBy: req.user._id });
  res.status(201).json({ message: "Vehicle added successfully.", vehicle });
});

const getVehicles = asyncHandler(async (req, res) => {
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 10, 1), 100);
  const filter = {};

  if (req.query.name) filter.vehicleName = { $regex: req.query.name, $options: "i" };
  if (req.query.type) filter.vehicleType = { $regex: `^${escapeRegex(req.query.type)}$`, $options: "i" };
  if (req.query.location) filter.location = { $regex: req.query.location, $options: "i" };

  const [vehicles, total] = await Promise.all([
    Vehicle.find(filter).sort({ createdAt: -1 }).skip((page - 1) * limit).limit(limit),
    Vehicle.countDocuments(filter)
  ]);

  res.json({
    vehicles,
    pagination: { total, page, limit, totalPages: Math.ceil(total / limit) }
  });
});

function escapeRegex(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

const getVehicleById = asyncHandler(async (req, res) => {
  const vehicle = await Vehicle.findById(req.params.id);
  if (!vehicle) return res.status(404).json({ message: "Vehicle not found." });
  res.json({ vehicle });
});

const updateVehicle = asyncHandler(async (req, res) => {
  const vehicle = await Vehicle.findByIdAndUpdate(
    req.params.id, req.body, { new: true, runValidators: true }
  );
  if (!vehicle) return res.status(404).json({ message: "Vehicle not found." });
  res.json({ message: "Vehicle updated successfully.", vehicle });
});

const deleteVehicle = asyncHandler(async (req, res) => {
  const vehicle = await Vehicle.findByIdAndDelete(req.params.id);
  if (!vehicle) return res.status(404).json({ message: "Vehicle not found." });
  res.json({ message: "Vehicle deleted successfully." });
});

export { createVehicle, getVehicles, getVehicleById, updateVehicle, deleteVehicle };
