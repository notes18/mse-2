import express from "express";
import { body, param } from "express-validator";
import {
  createBooking, getMyBookings, getBookingById, cancelBooking
} from "../controllers/bookingController.js";
import { protect } from "../middleware/authMiddleware.js";
import checkValidation from "../utils/validate.js";

const router = express.Router();

router.use(protect);
router.post("/",
  body("vehicleId").isMongoId().withMessage("A valid vehicleId is required."),
  body("pickupDate").notEmpty().withMessage("Pickup date is required."),
  body("returnDate").notEmpty().withMessage("Return date is required."),
  checkValidation,
  createBooking
);
router.get("/my", getMyBookings);
router.get("/:id", param("id").isMongoId(), checkValidation, getBookingById);
router.patch("/:id/cancel", param("id").isMongoId(), checkValidation, cancelBooking);

export default router;
