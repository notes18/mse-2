import express from "express";
import { body, param } from "express-validator";
import {
  createVehicle, getVehicles, getVehicleById, updateVehicle, deleteVehicle
} from "../controllers/vehicleController.js";
import { protect, authorize } from "../middleware/authMiddleware.js";
import checkValidation from "../utils/validate.js";

const router = express.Router();

const vehicleRules = [
  body("vehicleName").trim().notEmpty().withMessage("Vehicle name is required."),
  body("vehicleType").trim().notEmpty().withMessage("Vehicle type is required."),
  body("registrationNumber").trim().notEmpty().withMessage("Registration number is required."),
  body("seatingCapacity").isInt({ min: 1 }).withMessage("Seating capacity must be at least 1."),
  body("pricePerDay").isFloat({ gt: 0 }).withMessage("Price per day must be positive."),
  body("location").trim().notEmpty().withMessage("Location is required.")
];

router.get("/", getVehicles);
router.get("/:id", param("id").isMongoId(), checkValidation, getVehicleById);
router.post("/", protect, authorize("Admin"), vehicleRules, checkValidation, createVehicle);
router.put("/:id", protect, authorize("Admin"),
  param("id").isMongoId(),
  body("pricePerDay").optional().isFloat({ gt: 0 }),
  body("seatingCapacity").optional().isInt({ min: 1 }),
  checkValidation, updateVehicle
);
router.delete("/:id", protect, authorize("Admin"), param("id").isMongoId(), checkValidation, deleteVehicle);

export default router;
