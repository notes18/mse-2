import mongoose from "mongoose";

const vehicleSchema = new mongoose.Schema({
  vehicleName: { type: String, required: true, trim: true },
  vehicleType: { type: String, required: true, trim: true },
  registrationNumber: { type: String, required: true, unique: true, uppercase: true, trim: true },
  seatingCapacity: { type: Number, required: true, min: 1 },
  pricePerDay: { type: Number, required: true, min: 0.01 },
  location: { type: String, required: true, trim: true },
  availabilityStatus: { type: String, enum: ["Available", "Unavailable"], default: "Available" },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true }
}, { timestamps: true });

export default mongoose.model("Vehicle", vehicleSchema);
