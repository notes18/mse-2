# RentEase Backend

REST API for a vehicle rental and booking management system built with Node.js, Express, MongoDB and Mongoose.

## 1. Requirements

- Node.js 18 or later
- MongoDB running locally, or a MongoDB Atlas connection string
- Postman or Thunder Client for API testing

## 2. Install and run

```bash
npm install
```

Copy `.env.example` to `.env`, then set your own MongoDB URI and JWT secret.

```bash
# Linux / macOS
cp .env.example .env

# Windows PowerShell
Copy-Item .env.example .env
```

Start MongoDB, then run:

```bash
npm run dev
```

or:

```bash
npm start
```

Base URL: `http://localhost:5000`

## 3. Environment variables

| Variable | Description |
|---|---|
| PORT | API port (default 5000) |
| MONGO_URI | MongoDB connection string |
| JWT_SECRET | Long, private signing secret |
| JWT_EXPIRES_IN | Token lifetime (default 1d) |

Never commit `.env` or share your JWT secret.

## 4. Create an Admin

Public customer registration always creates a `Customer`; clients cannot choose their role. An existing Admin can create another Admin using the same login token used for other protected APIs:

```http
POST /api/auth/register-admin
Authorization: Bearer <admin-token>
Content-Type: application/json

{
  "name": "RentEase Admin",
  "email": "admin@example.com",
  "password": "admin123"
}
```

The route returns `401` without a valid JWT and `403` unless the token belongs to an Admin. To create the first Admin, promote a user directly in MongoDB using the command below.

If preferred, you can still create or promote an administrator directly in MongoDB:

```javascript
db.users.updateOne(
  { email: "admin@example.com" },
  { $set: { role: "Admin" } }
)
```

Log in again to obtain a token with the Admin role.

## 5. API endpoints

### Authentication

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/auth/register` | Register a Customer |
| POST | `/api/auth/login` | Login and receive JWT |
| POST | `/api/auth/register-admin` | Register an Admin (Admin JWT required) |

Register body:

```json
{ "name": "Asha", "email": "asha@example.com", "password": "secret123" }
```

Login body:

```json
{ "email": "asha@example.com", "password": "secret123" }
```

### Vehicles

Public read endpoints:

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/vehicles` | List/search/filter vehicles |
| GET | `/api/vehicles/:id` | Vehicle details |

Admin-only write endpoints (send `Authorization: Bearer <token>`):

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/vehicles` | Add a vehicle |
| PUT | `/api/vehicles/:id` | Update a vehicle |
| DELETE | `/api/vehicles/:id` | Delete a vehicle |

Vehicle body example:

```json
{
  "vehicleName": "Swift",
  "vehicleType": "Hatchback",
  "registrationNumber": "DL8CAB1234",
  "seatingCapacity": 5,
  "pricePerDay": 1800,
  "location": "Delhi",
  "availabilityStatus": "Available"
}
```

Search and pagination example:

`GET /api/vehicles?name=swift&type=Hatchback&location=Delhi&page=1&limit=10`

### Bookings

All booking endpoints require a valid JWT. Only Customer users may create bookings.

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/bookings` | Create booking |
| GET | `/api/bookings/my` | List logged-in user's bookings |
| GET | `/api/bookings/:id` | Get own booking (Admin can view any) |
| PATCH | `/api/bookings/:id/cancel` | Cancel own booking (Admin can cancel any) |

Create booking body:

```json
{
  "vehicleId": "REPLACE_WITH_VEHICLE_OBJECT_ID",
  "pickupDate": "2027-01-10",
  "returnDate": "2027-01-13"
}
```

Rental days are calculated by rounding a partial day up; total is `numberOfDays * pricePerDay`. Date ranges use the standard half-open overlap check, so a booking ending on the next booking's pickup date does not overlap. A cancelled booking is excluded from future overlap checks, releasing its dates.

## 6. Postman / Thunder Client test checklist

Capture screenshots from your own running API showing method, URL, request body, response and status:

1. Register a customer: `POST /api/auth/register` (201).
2. Login as customer: `POST /api/auth/login` (200); copy token.
3. Try `POST /api/vehicles` with customer token (403).
4. Promote a separate account to Admin using the MongoDB command above, login as Admin, then add a vehicle (201).
5. List vehicles and test filters/pagination (200).
6. Create a valid booking with customer token (201).
7. Get own bookings: `GET /api/bookings/my` (200).
8. Try another booking for overlapping dates (409).
9. Try a past pickup date or return date before pickup (400).
10. Call a protected endpoint without a token (401).
11. Cancel the booking (200), then book those dates again (201).

## 7. Notes

- Passwords are hashed with bcryptjs; passwords are never returned by the API.
- JWT authentication and role authorization protect write operations.
- Helmet adds HTTP security headers; rate limiting is applied to register/login.
- Express-validator validates incoming fields; Mongoose validates schemas.
- Centralized error middleware handles duplicate keys, invalid IDs and schema validation errors.
- For a production deployment, consider MongoDB transactions or an atomic reservation strategy to prevent two simultaneous requests from passing the overlap check at the same time.

## 8. Postman collection

Import `postman/RentEase-API.postman_collection.json` into Postman. The collection sets the base URL and captures customer/admin tokens and created resource IDs automatically.

Before running it:

1. Start MongoDB.
2. Create or promote the first administrator using the MongoDB instructions in the Create an Admin section.
3. Start the API with `npm start`.
4. Run the collection in the listed folder order.
