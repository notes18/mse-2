import express from "express";
import rateLimit from "express-rate-limit";
import { body } from "express-validator";
import { register, login, registerAdmin } from "../controllers/authController.js";
import { protect, authorize } from "../middleware/authMiddleware.js";
import checkValidation from "../utils/validate.js";

const router = express.Router();

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { message: "Too many authentication attempts. Try again later." }
});

router.post("/register",
  authLimiter,
  body("name").trim().notEmpty().withMessage("Name is required."),
  body("email").isEmail().withMessage("A valid email is required."),
  body("password").isLength({ min: 6 }).withMessage("Password must contain at least 6 characters."),
  checkValidation,
  register
);

router.post("/login",
  authLimiter,
  body("email").isEmail().withMessage("A valid email is required."),
  body("password").notEmpty().withMessage("Password is required."),
  checkValidation,
  login
);

router.post("/register-admin",
  authLimiter,
  protect,
  authorize("Admin"),
  body("name").trim().notEmpty().withMessage("Name is required."),
  body("email").isEmail().withMessage("A valid email is required."),
  body("password").isLength({ min: 6 }).withMessage("Password must contain at least 6 characters."),
  checkValidation,
  registerAdmin
);

export default router;
